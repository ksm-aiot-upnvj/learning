# Demo Express dan PostgreSQL

<!-- AI Generated -->

Contoh ini mencatat item dengan field name dan value melalui /api/items. Buat database PostgreSQL, salin .env.example ke .env, lalu sesuaikan DATABASE_URL dengan akun dan database lokal.

Jalankan npm ci di folder ini. Jalankan node index.js setelah instalasi selesai. Server memakai port 3000 pada konfigurasi contoh dan menyiapkan tabel items saat mulai.

Kirim POST dengan name dan value. Catat data.id dari respons, lalu cari ID itu pada array data dari GET /api/items.
