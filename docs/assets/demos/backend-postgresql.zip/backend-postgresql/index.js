import express from 'express';
import db from './db.js';

const app = express();

// 1. Parser JSON wajib agar req.body tidak undefined
app.use(express.json());

// 2. Custom logger middleware
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Auto-create tabel saat server menyala
const initDB = async () => {
  const createTableQuery = `
    CREATE TABLE IF NOT EXISTS items (
      id SERIAL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      value NUMERIC NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `;
  try {
    await db.query(createTableQuery);
    console.log('Database terhubung & tabel "items" siap digunakan.');
  } catch (error) {
    console.error('Gagal menginisialisasi tabel:', error.message);
    process.exit(1);
  }
};

app.get('/', (req, res) => {
  res.send('Selamat datang di API sederhana dengan Express dan PostgreSQL!');
});

// GET: Ambil semua data
app.get('/api/items', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM items ORDER BY id DESC');
    res.status(200).json({
      status: 'success',
      total: result.rowCount,
      data: result.rows,
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
});

// POST: Simpan data baru
app.post('/api/items', async (req, res) => {
  const { name, value } = req.body;

  if (!name || value === undefined) {
    return res.status(400).json({
      status: 'fail',
      message: 'Field "name" dan "value" wajib diisi',
    });
  }

  try {
    const query = 'INSERT INTO items (name, value) VALUES ($1, $2) RETURNING *';
    const result = await db.query(query, [name, value]);

    res.status(201).json({
      status: 'success',
      data: result.rows[0],
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: error.message,
    });
  }
});

const PORT = process.env.PORT;

initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
  });
});