# Demo Express dan MongoDB

<!-- AI Generated -->

Contoh ini menyediakan CRUD dokumen perangkat melalui /api/devices. Salin .env.example ke .env. Isi MONGO_HOST dan DB_NAME sesuai layanan MongoDB latihan.

Di folder ini, jalankan npx --yes pnpm@10.18.0 install --frozen-lockfile. Jalankan npm run dev pada terminal yang sama setelah instalasi selesai. Server mulai menerima request setelah koneksi ke MongoDB siap.

Konfigurasi contoh menggunakan port 3000. Jalankan node seed-api.js dari terminal lain untuk membuat satu dokumen perangkat per POST, dengan jeda sekitar 10 detik. Gunakan Ctrl+C untuk menghentikan script.
